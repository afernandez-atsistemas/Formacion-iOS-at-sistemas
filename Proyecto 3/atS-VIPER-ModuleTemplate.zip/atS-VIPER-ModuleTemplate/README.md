# atSistemas VIPER Module

This is the main VIPER module used on VIPER template based developments.

## Installation
Clone the repo and execute this command from the main folder:
```swift
sudo swift install.swift
```

## Usage
First of all, create a new group in Xcode with the module name you are going to create.

Inside this group, select New - File and choose *atS Module VIPER* as a file type. Enter the desired module name and press OK.

**Important**: After module creation it's strongly recommended to restart Xcode to avoid issues during the indexing process of the new content. 
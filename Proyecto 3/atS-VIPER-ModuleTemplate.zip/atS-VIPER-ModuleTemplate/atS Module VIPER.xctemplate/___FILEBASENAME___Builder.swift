//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//
//

import UIKit

class ___VARIABLE_productName:identifier___Builder {

    static func build() -> ___VARIABLE_productName:identifier___View {
        let view = ___VARIABLE_productName:identifier___View.init(nibName: String(describing: ___VARIABLE_productName:identifier___View.self), bundle: nil)
        let presenter = ___VARIABLE_productName:identifier___Presenter()
        let entity = ___VARIABLE_productName:identifier___Entity()
        let wireframe = ___VARIABLE_productName:identifier___Wireframe()
        
        let provider = MyProvider()
        let interactor = ___VARIABLE_productName:identifier___Interactor(provider: provider)
        
        view.presenter = presenter
        view.presenter.view = view
        view.presenter.entity = entity
        view.presenter.interactor = interactor
        view.presenter.interactor.output = presenter
        view.presenter.wireframe = wireframe
        
        view.presenter.wireframe.output = presenter
        view.presenter.wireframe.view = view
        
        return view
    }
}

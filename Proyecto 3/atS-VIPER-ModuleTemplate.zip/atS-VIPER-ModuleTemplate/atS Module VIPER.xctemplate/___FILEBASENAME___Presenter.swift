//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//
//

import Foundation

class ___VARIABLE_productName:identifier___Presenter: BasePresenter, ___VARIABLE_productName:identifier___PresenterContract {

    weak var view: ___VARIABLE_productName:identifier___ViewContract!
    var interactor: ___VARIABLE_productName:identifier___InteractorContract!
    var entity: ___VARIABLE_productName:identifier___EntityContract!
    var wireframe: ___VARIABLE_productName:identifier___WireframeContract!

    func viewDidLoad() {

    }

    func viewWillAppear() {

    }
}


// MARK: - ___VARIABLE_productName:identifier___InteractorOutputContract
extension ___VARIABLE_productName:identifier___Presenter: ___VARIABLE_productName:identifier___InteractorOutputContract {
    
}

// MARK: - ___VARIABLE_productName:identifier___WireframeOutputContract
extension ___VARIABLE_productName:identifier___Presenter: ___VARIABLE_productName:identifier___WireframeOutputContract {
    
}

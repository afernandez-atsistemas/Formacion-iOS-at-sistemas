//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//
//

import Foundation
import UIKit
import PromiseKit

protocol ___VARIABLE_productName:identifier___EntityContract: BaseEntity {
    
}

protocol ___VARIABLE_productName:identifier___ViewContract: BaseViewController {
    var presenter: ___VARIABLE_productName:identifier___PresenterContract! { get set }
    
}

protocol ___VARIABLE_productName:identifier___PresenterContract: BasePresenter {
    var view: ___VARIABLE_productName:identifier___ViewContract! { get set }
    var interactor: ___VARIABLE_productName:identifier___InteractorContract! { get set }
    var entity: ___VARIABLE_productName:identifier___EntityContract! { get set }
    var wireframe: ___VARIABLE_productName:identifier___WireframeContract! { get set }

    func viewDidLoad()
    func viewWillAppear()
}

protocol ___VARIABLE_productName:identifier___InteractorContract: BaseInteractor {
    var output: ___VARIABLE_productName:identifier___InteractorOutputContract! {get set}
}

protocol ___VARIABLE_productName:identifier___InteractorOutputContract: class {
    
}

protocol ___VARIABLE_productName:identifier___WireframeContract: BaseWireframe {
    var output: ___VARIABLE_productName:identifier___WireframeOutputContract! { get set }
    var view: UIViewController! { get set }
    
    func showBasicLoading(text: String)
    func hideBasicLoading(completion: @escaping (() -> Void))
}

protocol ___VARIABLE_productName:identifier___WireframeOutputContract: class {

}

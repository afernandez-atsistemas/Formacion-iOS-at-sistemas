//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//
//

import Foundation

class ___VARIABLE_productName:identifier___Entity: BaseEntity, ___VARIABLE_productName:identifier___EntityContract {

}
